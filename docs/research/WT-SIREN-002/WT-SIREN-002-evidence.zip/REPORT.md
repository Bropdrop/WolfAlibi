# WT-SIREN-002 — Independent Boundary Assurance

**Verdict: PASS for the shipped fixed synthetic Solitary worker on the tested host.** The verified assurance is `BROKER_ONLY`. WolfAlibi continues to report general confinement as `BLOCKED`.

## Scope and method

Ten sequential trials ran on Debian 13.7, Linux 6.18.57, with Bubblewrap 0.12.0, supervisor Python 3.12.14 and system worker Python 3.13.5. The runner operated in a separate network namespace. Each trial received an externally generated random 32-byte challenge, a unique run ID, and a fresh disposable state directory. The checkout was clean before and after execution. The tested commit was `774ea270ee00ea5728e8400f54c2fd70f8c467be`, tree `0b43d17c4b64e5bed82d9797143e4995c8089911`. Runtime binary and worker source hashes are recorded in the run reference. WT-SIREN-001 remains incomplete and its evidence was preserved.

The supported CLI performed the live trials. A separate process reverified each signed receipt offline using the separately exported reference contract, public keys, witness genesis, and recorded time. The evaluator matched the externally supplied run ID and challenge and compared measured worker source and interpreter hashes against files hashed before execution. Launcher and seccomp library hashes were cross-checked against the declared profile. A separate, read-only journal decoder verified every frame checksum and reconciled the complete journal with the digest and checkpoints in the signed receipt. All trusted components and the verifier ran under one lab operator.

## Results

| Check | Result |
| --- | --- |
| Fresh challenges, authorized broker operation and fresh store acceptance | 10/10 |
| Separate offline verification of original receipt | 10/10 historical VERIFIED |
| Signed payload altered | 10/10 REJECTED |
| Supervisor signature missing | 10/10 BLOCKED, exit 2 and no successful verification |
| Receipt checked at expiry using an explicit verifier time | 10/10 REJECTED for expiry |
| Unconsumed challenge checked at expiry in a newly issued verifier store | 10/10 REJECTED with genesis head intact. Ten paired in-window submissions were accepted in separate stores. |
| Consumed challenge replay in a copy of the original acceptance store | 10/10 REJECTED with witness head unchanged |
| Receipt and journal reconciliation | 10/10. One recorded authorized protected fixture read per trial and zero recorded protected writes. |
| Protected fixture postcondition | 10/10 exact expected bytes, mode 0400, and sole entry in the resource directory |
| Signed identity and isolation checks | 10/10 |
| Termination and cleanup | 10/10. Measured worker and launcher PIDs absent from host procfs after completion. All live trial state and verifier copies were removed after evidence export. |

Each journal contained a synthetic run marker event, its checkpoint, the authorized `protected.txt` read, and the terminal checkpoint. The response digest acknowledged in the transcript matched the independently read final fixture bytes. The run marker is bookkeeping and contributes zero to the count of authorized protected fixture reads. Verification controls operated on copies or isolated stores and performed zero broker operations.

The supervisor snapshot bound the invocation to the measured worker, recorded six differing namespace identities and private mounts with matching read-only runtime identities, and reported a single thread, zero capabilities, `no_new_privs`, the expected FD set, and a seccomp filter count greater than the launcher's. The signed closure included launcher reaping, pidfd exit, broker drain and peer hangup. The evaluator checked the original PIDs after exit and checked removal of the disposable directory after export. Kernel-wide resource inventory after teardown was outside the measured procedure.

## Latency

Ten sequential samples measured with the monotonic high-resolution host timer. CLI timings include subprocess start, interpreter startup and JSON output. Execution includes preflight, worker launch, broker interaction, signing and store acceptance. Replay measures the in-process store accept call including its lookup and excludes database open and copy. Values are milliseconds.

| Operation | Min | Median | Max |
| --- | ---: | ---: | ---: |
| Live execution with fresh acceptance | 278.208 | 323.360 | 361.565 |
| Historical verification | 105.698 | 125.605 | 144.491 |
| Altered evidence | 104.692 | 123.785 | 141.597 |
| Incomplete evidence | 99.184 | 115.539 | 186.267 |
| Expired historical verification | 103.375 | 121.612 | 127.675 |
| Consumed-challenge replay | 0.064 | 0.074 | 0.275 |

These are single-host descriptive measurements. No warmup runs were excluded from the final ten-trial series. Paired fresh-store expiry checks were evaluated for their outcome and witness head only.

## Interpretation

The journal and receipt establish the recorded broker operation. The immutable expected fixture bytes and final filesystem inspection establish the fixture postcondition. Worker-reported syscall attempts remain worker observations and do not establish a host-wide absence of access or transient effects. The supervisor provides the during-run observation. Post-exit checks were performed by the external evaluator. The kernel exposes filter mode and count, while exact filter semantics depend on the pinned worker bootstrap. The verifier uses public keys and expected inputs supplied by the same lab operator. The test exercises a fixed worker and one synthetic broker operation, with no claim of production readiness or equivalence with Anthropic Siren.

The first ten-trial series produced the intended `BLOCKED` response for every incomplete receipt, with the generic reason “supervisor record lacks required fields.” The runner incorrectly expected a field-specific reason. The raw first series is retained under `initial-evidence`. The final series matches the actual reason and includes the additional unconsumed-expiry control. Only the final series contributes to the result table and latency statistics.

## Reproduction and review

Use an existing clean checkout at the pinned commit and a Python 3.12 virtual environment with the checkout installed. The shipped profile also requires the system worker Python, Bubblewrap, libseccomp and the namespaces described in `docs/BYOA_SOLITARY_V1.md`. If preparing a fresh virtual environment, install the pinned dependencies from the source checkout before running in the isolated network namespace.

```sh
python3 -m venv /tmp/wt-siren-002-venv
cd /path/to/pinned/WolfAlibi
/tmp/wt-siren-002-venv/bin/python -m pip install -e '.[agent-all]'
cd /path/to/extracted/wt-siren-002
sha256sum -c SHA256SUMS
unshare --user --map-current-user --net /tmp/wt-siren-002-venv/bin/python \
  run.py /path/to/pinned/WolfAlibi /tmp/wt-siren-002-repeat --runs 10
```

Use a new output directory. The runner records the corpus before launching and returns exit 0 when all checks pass and the source is unchanged. Each trial retains raw CLI stdout and stderr, exact arguments with exits and timings, signed receipt and expectations, journal, fixture, witness, verifier store, control inputs, and reconciliation. `evidence/results.json` summarizes every final-series run. Retained receipts can also be checked by invoking `wolfalibi byoa verify --evidence <receipt> --expect <expectations>` against the raw original or individual control inputs. The manifest protects the integrity of the packaged files. The Solitary signatures and independently supplied public keys verify the receipt itself.
