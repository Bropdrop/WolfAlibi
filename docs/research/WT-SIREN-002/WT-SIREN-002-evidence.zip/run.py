"""Evaluate the unchanged fixed-worker profile and retain raw evidence."""
import argparse
from contextlib import closing
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time

from wolfalibi.stage35_verifier import VerifierStore

COMMIT = "774ea270ee00ea5728e8400f54c2fd70f8c467be"
TREE = "0b43d17c4b64e5bed82d9797143e4995c8089911"
FIXTURE = b"WolfAlibi Stage 3 synthetic protected bytes\n"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def frames(data):
    records = []
    while data:
        require(data[:7] == b"WALBJ2\0" and len(data) >= 43, "bad journal header")
        size = int.from_bytes(data[7:11], "big")
        end = 11 + size
        payload, checksum = data[11:end], data[end:end + 32]
        require(digest(payload) == checksum.hex(), "incomplete or invalid journal checksum")
        records.append(json.loads(payload))
        data = data[end + 32:]
    return records


def process_state(pid, ticks):
    path = Path(f"/proc/{pid}/stat")
    try:
        observed = path.read_text().rsplit(")", 1)[1].split()
    except FileNotFoundError:
        return "ABSENT"
    return "PID_REUSED" if int(observed[19]) != ticks else "STILL_PRESENT"


def inspect(inner, expected, envelope, artifact, pins):
    contract = expected["contract"]
    profile = contract["profile"]
    require(contract["fixture_sha256"] == digest(FIXTURE), "fixture reference mismatch")
    payload = envelope["supervisor_record"]["payload"]
    snapshot = payload["snapshot"]
    executable = snapshot["executable"]
    identity = snapshot["identity"]
    credentials = snapshot["credentials"]
    namespaces = snapshot["namespaces"]
    kernel = snapshot["solitary_kernel"]
    invocation = snapshot["invocation"]
    mounts = snapshot["mounts"]
    checks = {
        "worker_source": executable["argv_source_sha256"] == profile["worker_sha256"] == pins["worker"],
        "python_executable": executable["sha256"] == profile["python_sha256"] == pins["python"],
        "bubblewrap_executable": profile["launcher_sha256"] == pins["bubblewrap"],
        "seccomp_library": profile["solitary"]["seccomp"]["library_sha256"] == pins["seccomp"],
        "invocation_binding": invocation["challenge"] == contract["challenge"]
            and invocation["run_id"] == contract["run_id"]
            and invocation["fixture_key"] == contract["key"],
        "worker_parent": identity["worker_parent_pid"] == identity["launcher_pid"]
            and identity["worker_namespace_pid"] == 1 and identity["stability"] == "procdir+pidfd",
        "separate_namespaces": set(namespaces) == {"ipc", "mnt", "net", "pid", "user", "uts"}
            and all(pair["worker"] != pair["supervisor"] for pair in namespaces.values()),
        "credentials": credentials["no_new_privs"] == 1 and credentials["threads"] == 1
            and credentials["uid"] == credentials["gid"] == [1000] * 4
            and all(value == 0 for value in credentials["capabilities"].values()),
        "seccomp": credentials["seccomp_mode"] == 2
            and kernel["worker_seccomp_filters"] > kernel["launcher_seccomp_filters"],
        "descriptors": set(snapshot["descriptors"]) == {"0", "1", "2"}
            and snapshot["descriptors"]["0"]["kind"] == "socket"
            and str(invocation["canary_fd"]) not in snapshot["descriptors"],
        "environment": kernel["environment_keys"] == ["PWD"],
        "mounts": snapshot["protected_root_visible"] is False and bool(mounts)
            and all(mount["private"] for mount in mounts)
            and all("ro" in mount["flags"] and mount["observed_identity"] == mount["expected_identity"]
                    for mount in mounts if mount["source"] is not None),
        "closure": all(payload["closure"].values()) and len(payload["closure"]) == 4,
    }
    process = {name: process_state(identity[f"{name}_pid"], identity[f"{name}_start_ticks"])
               for name in ("worker", "launcher")}
    checks["processes_gone"] = all(state != "STILL_PRESENT" for state in process.values())
    resources = inner / "resources"
    fixture = resources / "protected.txt"
    fixture_bytes = fixture.read_bytes()
    checks["fixture_integrity"] = (fixture_bytes == FIXTURE
        and stat.S_ISREG(fixture.lstat().st_mode)
        and stat.S_IMODE(fixture.lstat().st_mode) == 0o400
        and sorted(item.name for item in resources.iterdir()) == ["protected.txt"])
    raw = (inner / "broker.wal").read_bytes()
    broker = envelope["evidence"]["payload"]
    start, start_seal, read, end_seal = frames(raw)
    marker_leaf = bytes.fromhex(broker["start"]["leaves"][0])
    marker_size = int.from_bytes(marker_leaf[:4], "big")
    read_key = contract["key"].encode()
    read_leaf = len(read_key).to_bytes(4, "big") + read_key + bytes.fromhex("01000000010000000000000002")
    checks["wal_matches_receipt"] = (
        digest(raw) == broker["journal_sha256"]
        and start == {"k": marker_leaf[4:4 + marker_size].hex(), "m": 1, "seq": 1, "t": "e"}
        and read == {"k": read_key.hex(), "m": 1, "seq": 2, "t": "e"}
        and start_seal == {"t": "s", "epoch": 0, **broker["start"]}
        and end_seal == {"t": "s", "epoch": 1, **broker["end"]}
        and broker["end"]["leaves"] == [read_leaf.hex()]
    )
    checks["response_matches_fixture"] = broker["observations"]["response_sha256"] == digest(fixture_bytes)
    save(artifact / "reconciliation.json", {
        "checks": checks, "post_exit_proc_check": process, "decoded_wal": [start, start_seal, read, end_seal],
        "fixture_sha256": digest(fixture_bytes),
        "authorized_fixture_reads": 1 if checks["wal_matches_receipt"] else None,
        "broker_recorded_protected_writes": 0 if checks["wal_matches_receipt"] else None,
        "worker_self_report": payload["worker_self_report"],
        "worker_reported_observations": broker["observations"],
    })
    require(all(checks.values()), f"failed reconciliation: {[k for k in checks if not checks[k]]}")


def command(source, artifact, label, args):
    start = time.perf_counter_ns()
    done = subprocess.run(args, cwd=source, capture_output=True, timeout=30)
    elapsed = time.perf_counter_ns() - start
    (artifact / f"{label}.stdout").write_bytes(done.stdout)
    (artifact / f"{label}.stderr").write_bytes(done.stderr)
    save(artifact / f"{label}.command.json", {
        "argv": args, "cwd": str(source), "exit": done.returncode, "latency_ns": elapsed,
    })
    return done.returncode, json.loads(done.stdout), elapsed


def one(source, artifact, run_id, challenge, pins):
    artifact.mkdir()
    cli = [sys.executable, "-m", "wolfalibi_cli", "byoa"]
    row = {"run_id": run_id, "challenge": challenge, "result": "INCONCLUSIVE",
           "checks": dict.fromkeys(("execution", "historical", "altered", "incomplete",
                                    "expired", "expired_fresh", "replay", "reconciliation"), "NOT_RUN")}
    disposable = Path(tempfile.mkdtemp(prefix="wt-siren-002-"))
    state = disposable / "state"
    try:
        code, trial, elapsed = command(source, artifact, "trial", cli + [
            "test", "--manifest", "examples/byoa_solitary_manifest.json",
            "--profile", "solitary-synthetic", "--consent", "--state-dir", str(state),
            "--run-id", run_id, "--challenge", challenge])
        row["execution_latency_ns"] = elapsed
        require(code == 0 and trial["outcome"] == "COMPLETED", f"trial did not complete: {trial}")
        require(trial["fresh_acceptance"]["outcome"] == "VERIFIED", "fresh acceptance missing")
        row["checks"]["execution"] = "PASS"
        inner, = state.glob("stage3-*")
        for path in (state / "expected.json", state / "evidence.json", state / "verifier.db",
                     state / "witness.json", inner / "broker.wal", inner / "resources/protected.txt"):
            shutil.copyfile(path, artifact / path.name)
        expect = artifact / "expected.json"
        receipt = artifact / "evidence.json"
        expected = json.loads(expect.read_bytes())
        envelope = json.loads(receipt.read_bytes())
        require(expected["contract"]["run_id"] == run_id and expected["contract"]["challenge"] == challenge,
                "external run reference mismatch")
        altered = deepcopy(envelope)
        altered["supervisor_record"]["payload"]["observed_limits"]["RLIMIT_FSIZE"][0] += 1
        save(artifact / "altered.json", altered)
        incomplete = deepcopy(envelope)
        del incomplete["supervisor_record"]["signature"]
        save(artifact / "incomplete.json", incomplete)
        save(artifact / "expired-expectation.json", {**expected, "now": expected["contract"]["expires_at"]})
        for label, evidence_path, expectation, wanted, reason in (
            ("historical", receipt, expect, "VERIFIED", None),
            ("altered", artifact / "altered.json", expect, "REJECTED", "signature"),
            ("incomplete", artifact / "incomplete.json", expect, "BLOCKED", "lacks required fields"),
            ("expired", receipt, artifact / "expired-expectation.json", "REJECTED", "expired"),
        ):
            code, result, elapsed = command(source, artifact, label, cli + [
                "verify", "--evidence", str(evidence_path), "--expect", str(expectation)])
            row[label + "_latency_ns"] = elapsed
            matched = (code == (0 if wanted == "VERIFIED" else 2) and result["outcome"] == wanted
                       and (reason is None or reason in result.get("reason", "")))
            row["checks"][label] = "PASS" if matched else "FAIL"
        terminal = bytes.fromhex(json.loads((artifact / "historical.stdout").read_bytes())["witness_state_digest"])
        witness = bytes.fromhex(expected["witness_pub"])
        copy = disposable / "verifier-copy.db"
        with closing(sqlite3.connect((state / "verifier.db").as_uri() + "?mode=ro", uri=True)) as original:
            with closing(sqlite3.connect(copy)) as target:
                original.backup(target)
        with VerifierStore(copy, expected_heads={witness: terminal}) as verifier:
            start = time.perf_counter_ns()
            replay = verifier.accept(envelope["evidence"], challenge=challenge,
                                     supervisor_record=envelope["supervisor_record"], now=expected["now"])
            row["replay_latency_ns"] = time.perf_counter_ns() - start
            unchanged = verifier.head(witness) == terminal
        save(artifact / "replay.json", {"result": replay, "witness_head_unchanged": unchanged})
        row["checks"]["replay"] = ("PASS" if replay["outcome"] == "REJECTED"
                                  and "consumed" in replay.get("reason", "") and unchanged else "FAIL")
        # Re-enroll in isolated stores so expiry is exercised before consumption.
        genesis = bytes.fromhex(expected["expected_witness_state_digest"])
        keys = {key: bytes.fromhex(expected[key])
                for key in ("broker_pub", "witness_pub", "supervisor_pub")}
        attempts = {}
        for label, clock in (("in_window", expected["now"]),
                             ("expired", expected["contract"]["expires_at"])):
            with VerifierStore(disposable / f"{label}.db", bootstrap_heads={witness: genesis}) as verifier:
                issued = verifier.issue(contract=expected["contract"], now=expected["now"], **keys)
                require(issued["outcome"] == "ISSUED", f"control issuance failed: {issued}")
                result = verifier.accept(envelope["evidence"], challenge=challenge,
                                         supervisor_record=envelope["supervisor_record"], now=clock)
                attempts[label] = {"now": clock, "result": result, "issued": issued,
                                   "head": verifier.head(witness).hex()}
        save(artifact / "fresh-validity-window.json", attempts)
        row["checks"]["expired_fresh"] = (
            "PASS" if attempts["in_window"]["result"]["outcome"] == "VERIFIED"
            and attempts["in_window"]["head"] == terminal.hex()
            and attempts["expired"]["result"]["outcome"] == "REJECTED"
            and "validity window" in attempts["expired"]["result"].get("reason", "")
            and attempts["expired"]["head"] == genesis.hex() else "FAIL"
        )
        inspect(inner, expected, envelope, artifact, pins)
        row["checks"]["reconciliation"] = "PASS"
        row["result"] = "PASS" if all(value == "PASS" for value in row["checks"].values()) else "FAIL"
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as exc:
        row["error"] = str(exc)
    finally:
        shutil.rmtree(disposable)
        row["disposable_state_removed"] = not disposable.exists()
        save(artifact / "result.json", row)
    return row


def git(source, *args):
    return subprocess.check_output(["git", "-C", str(source), *args], text=True).splitlines()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--runs", type=int, default=10)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    require(args.runs > 0, "at least one trial required")
    require(not output.is_relative_to(source), "write evidence outside source")
    require(git(source, "rev-parse", "HEAD", "HEAD^{tree}") == [COMMIT, TREE], "wrong revision")
    require(not git(source, "status", "--porcelain"), "checkout is dirty")
    output.mkdir()
    pins = {name: digest(path.read_bytes()) for name, path in {
        "worker": source / "wolfalibi/solitary_worker.py",
        "bubblewrap": Path("/usr/bin/bwrap"),
        "python": Path("/usr/bin/python3").resolve(),
        "seccomp": Path("/usr/lib/x86_64-linux-gnu/libseccomp.so.2"),
    }.items()}
    save(output / "reference.json", {
        "commit": COMMIT, "tree": TREE, "sha256": pins, "kernel": os.uname().release,
        "host_python": sys.version, "outer_network_namespace": os.readlink("/proc/self/ns/net"),
    })
    corpus = [(f"wt-siren-002-{i:03}", secrets.token_hex(32)) for i in range(1, args.runs + 1)]
    require(len(set(nonce for _, nonce in corpus)) == args.runs, "duplicate challenges")
    save(output / "planned-runs.json", corpus)
    rows = [one(source, output / run_id, run_id, nonce, pins) for run_id, nonce in corpus]
    unchanged = (git(source, "rev-parse", "HEAD", "HEAD^{tree}") == [COMMIT, TREE]
                 and not git(source, "status", "--porcelain"))
    passed = unchanged and all(row["result"] == "PASS" and row["disposable_state_removed"] for row in rows)
    save(output / "results.json", {"outcome": "PASS" if passed else "INCONCLUSIVE",
                                    "source_clean_and_unchanged": unchanged, "runs": rows})
    return 0 if passed else 2


if __name__ == "__main__":
    os.umask(0o077)
    raise SystemExit(main())
